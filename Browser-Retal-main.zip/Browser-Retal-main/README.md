# Browser-Retal
F-29 Retatliator in the browser using JS-DOS. The original copy protection is bypassed for this version of F29 Retaliator. When the game prompts you to enter a number-letter combination on the “Pilot Authorisation” screen, type any number and press enter to play the game.

### How to play
Enter the following commands
1) `cd RETAL`
2) `RETAL.BAT`

Use Tab to autocomplete commands

### DOSBox Shortcuts
While running the game in windowed mode, it may be useful to use DOSBox's Control+F10 shortcut to bind the mouse into the game window. This will prevent the cursor from going outside the game window during gameplay while steering with the mouse. Pressing Control+F10 again will unlock the mouse from the game window. You can also use Control+F12 to speed up the game if it lags too much and Control+F11 to slow it down.

### Controls:
Chromebook users might encounter some problems because some keys are missing on chromebooks.
![image](https://github.com/catfoolyou/Browser-Retal/assets/95507639/0b6ec734-c73d-48b6-8a18-160908b966c1)
